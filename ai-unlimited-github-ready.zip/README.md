# AI UNLIMITED

A premium Arabic-first unified AI chat starter with server-side provider fallback.

## What is included
- Responsive RTL chat UI with saved local chat history.
- Server-side API route (keys never sent to the browser).
- Configurable OpenAI-compatible providers.
- Sequential fallback when a provider returns rate-limit/quota or temporary availability errors.
- Provider/model label in successful responses.
- `.env.example` and deployment notes.

## Important scope
This is a working starter/MVP, not a claim that every AI provider is free or that free quotas can be bypassed. It uses only API access you are authorized to use. Each provider has its own terms, quotas, and reset behavior. This starter does not yet include hosted authentication, a shared database, admin management, image generation, file analysis, or streaming responses.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Add valid API keys for providers you are authorized to use.
4. Configure `AI_PROVIDERS_JSON` as valid JSON. `apiKeyEnv` must match an environment variable name.
5. Run:
   ```bash
   npm install
   npm run dev
   ```
6. Open http://localhost:3000.

## Add another provider
Add an object to `AI_PROVIDERS_JSON`:
```json
{
  "name": "Provider Name",
  "baseUrl": "https://provider.example/v1",
  "model": "model-id",
  "apiKeyEnv": "PROVIDER_API_KEY",
  "enabled": true
}
```
The endpoint must implement the OpenAI-compatible `/chat/completions` API. Add the key as a server environment variable. Do not commit `.env.local`.

## Fallback behavior
The router tries providers in configured order. It moves to the next provider on HTTP 408, 429, 500, 502, 503, 504 or network/timeout errors. It does not silently treat authentication/configuration errors as quota exhaustion.

## Deploy to Vercel
Import the repository into Vercel, add `AI_PROVIDERS_JSON` and the required provider key environment variables in Project Settings → Environment Variables, then redeploy.

## Production checklist
Before public launch, add managed authentication, PostgreSQL persistence, per-user rate limits, usage/cost tracking, admin roles, abuse protection, request logging with secret redaction, and provider-specific quota reset handling.
