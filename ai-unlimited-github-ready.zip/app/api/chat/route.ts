import { NextRequest, NextResponse } from "next/server";
import { getProviders } from "@/lib/providers";

export const runtime = "nodejs";
export const maxDuration = 60;

type ChatMessage = { role: "user" | "assistant" | "system"; content: string };

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages = body.messages as ChatMessage[];
    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "أرسل رسالة صحيحة." }, { status: 400 });
    }

    const providers = getProviders();
    if (!providers.length) {
      return NextResponse.json({
        error: "لا يوجد مزود AI مهيأ. أضف مفاتيح API صحيحة في متغيرات البيئة."
      }, { status: 503 });
    }

    const failures: string[] = [];
    for (const provider of providers) {
      const key = process.env[provider.apiKeyEnv];
      if (!key) continue;
      try {
        const response = await fetch(`${provider.baseUrl.replace(/\/$/, "")}/chat/completions`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: provider.model,
            messages,
            temperature: 0.7
          }),
          signal: AbortSignal.timeout(45000)
        });

        if (!response.ok) {
          const detail = await response.text().catch(() => "");
          failures.push(`${provider.name}: HTTP ${response.status}`);
          // Fallback only for quota, rate limits and temporary provider errors.
          if ([408, 429, 500, 502, 503, 504].includes(response.status)) continue;
          return NextResponse.json({
            error: `فشل الاتصال مع ${provider.name} (HTTP ${response.status}). تحقق من المفتاح والإعدادات.`,
            detail: detail.slice(0, 500)
          }, { status: 502 });
        }

        const data = await response.json();
        const content = data?.choices?.[0]?.message?.content;
        if (typeof content !== "string" || !content.trim()) {
          failures.push(`${provider.name}: empty response`);
          continue;
        }
        return NextResponse.json({ content, provider: provider.name, model: provider.model });
      } catch (error) {
        failures.push(`${provider.name}: ${(error as Error).message}`);
      }
    }

    return NextResponse.json({
      error: "لم ينجح أي مزود متاح حالياً. قد تكون الحصص انتهت أو الخدمات غير متاحة.",
      attempted: failures
    }, { status: 503 });
  } catch {
    return NextResponse.json({ error: "حدث خطأ داخلي أثناء معالجة الطلب." }, { status: 500 });
  }
}
