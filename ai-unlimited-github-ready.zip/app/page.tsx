 "use client";

import { useEffect, useRef, useState } from "react";
import { Activity, ArrowUp, Bot, Check, ChevronDown, CircleHelp, Cpu, Menu, MessageSquare, Plus, Settings2, ShieldCheck, Sparkles, Zap } from "lucide-react";

type Message = { role: "user" | "assistant"; content: string; model?: string };
type Chat = { id: string; title: string; messages: Message[] };

const starters = [
  { icon: "✦", title: "اكتب لي فكرة مشروع", desc: "حوّل فكرة بسيطة إلى خطة تنفيذ" },
  { icon: "⌘", title: "ساعدني بالبرمجة", desc: "حلّل الكود واكتشف الأخطاء" },
  { icon: "◈", title: "لخّص مستنداً", desc: "استخرج أهم النقاط بسرعة" },
  { icon: "◎", title: "اشرح موضوعاً معقداً", desc: "شرح واضح خطوة بخطوة" }
];

export default function Home() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeId, setActiveId] = useState("new");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [modelMode, setModelMode] = useState("AUTO");
  const bottomRef = useRef<HTMLDivElement>(null);
  const active = chats.find(c => c.id === activeId);
  const messages = active?.messages ?? [];

  useEffect(() => {
    try {
      const saved = localStorage.getItem("ai-unlimited-chats");
      if (saved) setChats(JSON.parse(saved));
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem("ai-unlimited-chats", JSON.stringify(chats));
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chats]);

  function newChat() { setActiveId("new"); setInput(""); }
  function updateMessages(id: string, next: Message[]) {
    setChats(prev => {
      const exists = prev.some(c => c.id === id);
      if (!exists) return [{ id, title: next.find(m => m.role === "user")?.content.slice(0, 34) || "محادثة جديدة", messages: next }, ...prev];
      return prev.map(c => c.id === id ? { ...c, messages: next } : c);
    });
  }

  async function send(text = input) {
    const prompt = text.trim();
    if (!prompt || busy) return;
    const id = activeId === "new" ? crypto.randomUUID() : activeId;
    setActiveId(id); setInput(""); setBusy(true);
    const next = [...messages, { role: "user" as const, content: prompt }];
    updateMessages(id, [...next, { role: "assistant", content: "جاري التفكير..." }]);
    try {
      const response = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next, mode: modelMode })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تنفيذ الطلب");
      updateMessages(id, [...next, { role: "assistant", content: data.content, model: data.provider }]);
    } catch (e) {
      updateMessages(id, [...next, { role: "assistant", content: `تعذر الحصول على إجابة: ${(e as Error).message}\n\nتأكد من إعداد مفاتيح API في إعدادات الخادم.` }]);
    } finally { setBusy(false); }
  }

  return <main className="shell">
    <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Sparkles size={20}/></div><div><b>AI <span>UNLIMITED</span></b><small>INTELLIGENCE HUB</small></div></div>
      <button className="new-chat" onClick={newChat}><Plus size={17}/> محادثة جديدة</button>
      <div className="side-label">مساحة العمل</div>
      <button className="side-item selected"><MessageSquare size={17}/> المحادثات</button>
      <button className="side-item" onClick={() => alert("مركز النماذج: أضف مزودين من إعدادات الخادم حالياً.")}><Cpu size={17}/> مركز النماذج <span className="tiny-count">AI</span></button>
      <button className="side-item" onClick={() => alert("إحصائيات الاستخدام ستتوفر بعد ربط قاعدة البيانات.")}><Activity size={17}/> إحصائيات الاستخدام</button>
      <div className="side-label history-label">الأخيرة</div>
      <div className="history">{chats.map(c => <button key={c.id} className={`history-item ${activeId === c.id ? "active" : ""}`} onClick={() => setActiveId(c.id)}><MessageSquare size={14}/><span>{c.title}</span></button>)}</div>
      <div className="sidebar-bottom"><div className="secure"><ShieldCheck size={16}/><span>مفاتيحك تبقى على الخادم</span></div><button className="side-item" onClick={() => alert("الإعدادات المتقدمة: راجع ملف README لإعداد مزودي API.")}><Settings2 size={17}/> الإعدادات</button></div>
    </aside>

    <section className="main">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={() => setMenuOpen(!menuOpen)}><Menu size={19}/></button>
        <div className="crumb">مساحة العمل <span>/</span> <b>محادثة ذكية</b></div>
        <div className="top-actions"><div className="status"><i/> نظام التوجيه جاهز</div><button className="icon-btn" title="معلومات"><CircleHelp size={18}/></button><div className="avatar">A</div></div>
      </header>

      <div className="content">
        {messages.length === 0 ? <div className="welcome">
          <div className="eyebrow"><span className="pulse"/> UNIFIED AI WORKSPACE</div>
          <div className="hero-icon"><Sparkles size={29}/></div>
          <h1>كل نماذج الذكاء.<br/><em>في مكان واحد.</em></h1>
          <p className="subtitle">ابدأ محادثتك، ودع محرك التوجيه الذكي يختار النموذج المناسب<br className="desktop"/> وينتقل إلى بديل عند تعذّر الخدمة.</p>
          <div className="mode-row"><span>وضع التشغيل</span><div className="mode-select"><Zap size={14}/><select value={modelMode} onChange={e => setModelMode(e.target.value)}><option value="AUTO">تلقائي ذكي</option><option value="FAST">الأسرع أولاً</option><option value="FREE">المجاني أولاً</option></select><ChevronDown size={13}/></div></div>
          <div className="starter-grid">{starters.map(s => <button key={s.title} className="starter" onClick={() => send(s.title)}><span className="starter-icon">{s.icon}</span><b>{s.title}</b><small>{s.desc}</small></button>)}</div>
        </div> : <div className="conversation">
          <div className="conversation-head"><div><span className="eyebrow">YOUR WORKSPACE</span><h2>{active?.title || "محادثة جديدة"}</h2></div><div className="mode-select"><Zap size={14}/><select value={modelMode} onChange={e => setModelMode(e.target.value)}><option value="AUTO">تلقائي ذكي</option><option value="FAST">الأسرع أولاً</option><option value="FREE">المجاني أولاً</option></select></div></div>
          {messages.map((m, i) => <article key={i} className={`message ${m.role}`}><div className="message-avatar">{m.role === "user" ? "أ" : <Sparkles size={16}/>}</div><div className="message-body"><div className="message-meta">{m.role === "user" ? "أنت" : "AI UNLIMITED"}{m.model && <span className="model-tag"><Check size={11}/> {m.model}</span>}</div><p>{m.content}</p></div></article>)}
          <div ref={bottomRef}/>
        </div>}
      </div>

      <div className="composer-wrap"><div className="composer"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="اكتب رسالتك هنا... اسأل، حلّل، ابتكر" rows={1}/><div className="composer-foot"><span><span className="green-dot"/> توجيه تلقائي للنماذج المتاحة</span><button className="send-btn" disabled={!input.trim() || busy} onClick={() => send()}>{busy ? <span className="spinner"/> : <ArrowUp size={19}/>}</button></div></div><div className="disclaimer">قد تختلف حدود الاستخدام حسب مزود الخدمة ومفاتيح API المتاحة.</div></div>
    </section>
  </main>;
}
