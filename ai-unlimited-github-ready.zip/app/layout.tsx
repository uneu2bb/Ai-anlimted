import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI UNLIMITED — One platform. Many models.",
  description: "A unified AI workspace with intelligent provider fallback."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
